import { Band } from "@/types/band";

export const bandsData: Band[] = [
  {
    id: 1,
    name: "Three Man Down",
    genre: "Pop Rock",
    imageUrl: "/images/bands/band1.jpg",
    members: [
      { id: 101, name: "กิต", role: "นักร้องนำ" },
      { id: 102, name: "ตูน", role: "มือกีตาร์" },
      { id: 103, name: "เต", role: "มือกลอง" },
      { id: 104, name: "เส็ง", role: "มือคีย์บอร์ด" },
    ],
  },
  {
    id: 2,
    name: "Tattoo Colour",
    genre: "Pop / Indie Rock",
    imageUrl: "/images/bands/band2.jpg",
    members: [
      { id: 201, name: "ดิม", role: "นักร้องนำ" },
      { id: 202, name: "รัฐ", role: "มือกีตาร์" },
      { id: 203, name: "ตั้ม", role: "มือกลอง" },
      { id: 204, name: "จั๊ม", role: "มือเบส" },
    ],
  },
  {
    id: 3,
    name: "Cocktail",
    genre: "Classic Rock",
    imageUrl: "/images/bands/band3.jpg",
    members: [
      { id: 301, name: "โอม", role: "นักร้องนำ" },
      { id: 302, name: "เชาว์", role: "มือกีตาร์" },
      { id: 303, name: "ปาร์ค", role: "มือเบส" },
      { id: 304, name: "ฟิลิปส์", role: "มือกลอง" },
    ],
  },
];
